from boto.connection import AWSAuthConnection

class ESConnection(AWSAuthConnection):

    def __init__(self, region, **kwargs):
        super(ESConnection, self).__init__(**kwargs)
        self._set_auth_region_name(region)
        self._set_auth_service_name("es")

    def _required_auth_capability(self):
        return ['hmac-v4']

if __name__ == "__main__":

    client = ESConnection(
            region='sa-east-1',
            host='search-elk-kubernetes-logs-prd-qka6ohseif37hxwkdmq44f2nyq.sa-east-1.es.amazonaws.com',
            aws_access_key_id='AKIAJAWVX224HR4OJHBA',
            aws_secret_access_key='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', 
            is_secure=False)

    print 'Registering Snapshot Repository'
    resp = client.make_request(
            method='PUT',
            path='/_snapshot/k8s-kops-cluster-logs-storage-prd',
            data='{"type": "s3","settings": { "bucket": "k8s-kops-cluster-logs-storage-prd","region": "sa-east-1","role_arn": "arn:aws:iam::817525770676:role/k8s-kops-cluster-logs-storage-prd-s3-access"}}',
            headers={'Content-Type': 'application/json'})
    body = resp.read()
    print body