from boto.connection import AWSAuthConnection

class ESConnection(AWSAuthConnection):

    def __init__(self, region, **kwargs):
        super(ESConnection, self).__init__(**kwargs)
        self._set_auth_region_name(region)
        self._set_auth_service_name("es")

    def _required_auth_capability(self):
        return ['hmac-v4']

if __name__ == "__main__":

    client = ESConnection(
            region='sa-east-1',
            host='search-elk-kubernetes-logs-dev-2xitu55qafiwh4hc4ik2qixaee.sa-east-1.es.amazonaws.com',
            aws_access_key_id='AKIAIITYDVJPYJSGYPFQ',
            aws_secret_access_key='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', 
            is_secure=False)

    print 'Registering Snapshot Repository'
    resp = client.make_request(
            method='PUT',
            path='/_snapshot/k8s-kops-cluster-logs-storage-dev',
            data='{"type": "s3","settings": { "bucket": "k8s-kops-cluster-logs-storage-dev","region": "sa-east-1","role_arn": "arn:aws:iam::459502771752:role/k8s-kops-cluster-logs-storage-dev-s3-access"}}',
            headers={'Content-Type': 'application/json'})
    body = resp.read()
    print body