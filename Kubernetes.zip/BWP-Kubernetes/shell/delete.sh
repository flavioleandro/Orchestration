kubectl delete svc/minikube-service deploy/minikube-deployment ing/minikube-ingress
kubectl delete svc/bootcamp-service deploy/bootcamp-deployment ing/bootcamp-ingress
kubectl delete svc/manager-keys-service deploy/manager-keys-deployment ing/manager-keys-ingress
kubectl delete cm/nginx-configmap svc/nginx-service deploy/nginx-deployment ing/nginx-ingress
