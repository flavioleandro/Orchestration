kubectl get secret,configmap,deployments,services,pods,ingress,hpa;
