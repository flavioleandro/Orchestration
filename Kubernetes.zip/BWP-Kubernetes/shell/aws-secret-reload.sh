aws ecr get-login --region=us-east-1 | sh
echo Logged!
cat > /tmp/image-pull-secret.yaml << EOF
apiVersion: v1
kind: Secret
metadata:
  name: aws-secret
data:
  .dockerconfigjson: $(cat ~/.docker/config.json | base64 -w 0)
type: kubernetes.io/dockerconfigjson
EOF
echo YAML Created!
kubectl replace -f /tmp/image-pull-secret.yaml
