kubectl create -f nginx-configmap.yaml;
kubectl create -f minikube-service-deployment.yaml;
kubectl create -f bootcamp-service-deployment.yaml;
kubectl create -f manager-keys-service-deployment.yaml;
kubectl create -f nginx-service.yaml;
kubectl create -f nginx-deployment.yaml;
kubectl get sercret,configmap,deployments,services,pods,ingress,hpa;
