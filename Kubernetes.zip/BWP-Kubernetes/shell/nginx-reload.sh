nginx=$(kubectl get pods -l app=nginx-internal-deployment --output=jsonpath={.items..metadata.name})
echo $nginx
for n in $nginx; do kubectl exec -it $n -- /bin/bash service nginx reload; done
nginx=$(kubectl get pods -l app=nginx-public-deployment --output=jsonpath={.items..metadata.name})
echo $nginx
for n in $nginx; do kubectl exec -it $n -- /bin/bash service nginx reload; done
