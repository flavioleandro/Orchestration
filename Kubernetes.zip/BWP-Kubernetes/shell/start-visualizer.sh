cd /home/ec2-user/haproxy-1.6.3
sudo ./haproxy -f /etc/haproxy.cfg
cd ../gcp-live-k8s-visualizer
kubectl proxy --www=. --accept-hosts '.*'